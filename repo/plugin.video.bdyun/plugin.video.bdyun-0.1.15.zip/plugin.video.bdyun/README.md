# plugin.video.bdyun
## Project Homepage
* [caasiu/plugin.video.bdyun](https://github.com/caasiu/plugin.video.bdyun.git)

## License
* plugin.video.bdyun is released under the GPLv3 License. See [LICENSE](LICENSE) for details.

## 截图
![screenshot](screenshot.png)
